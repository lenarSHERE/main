# labs-dev_programm_module 
lab1, lab3, lab4, lab5, lab6

<div align="center">
<img src="https://media.tenor.com/cZCGGNbpWskAAAAi/miyulily-vtuber.gif" title="anime-image" width="70px"/>
</div>
